//
//  LAAppDelegate.h
//  lottie-ios
//
//  Created by Brandon Withrow on 01/26/2017.
//  Copyright (c) 2017 Brandon Withrow. All rights reserved.
//

@import UIKit;

@interface LAAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
