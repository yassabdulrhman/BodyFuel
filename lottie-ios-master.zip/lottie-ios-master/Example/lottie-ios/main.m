//
//  main.m
//  lottie-ios
//
//  Created by Brandon Withrow on 01/26/2017.
//  Copyright (c) 2017 Brandon Withrow. All rights reserved.
//

@import UIKit;
#import "LAAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LAAppDelegate class]));
    }
}
