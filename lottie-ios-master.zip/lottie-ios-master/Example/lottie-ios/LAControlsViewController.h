//
//  LAControlsViewController.h
//  lottie-ios
//
//  Created by brandon_withrow on 8/28/17.
//  Copyright © 2017 Brandon Withrow. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LAControlsViewController : UIViewController

@end
