//
//  ViewController.h
//  Example for lottie-macos
//
//  Created by Oleksii Pavlovskyi on 2/2/17.
//  Copyright © 2017 Brandon Withrow. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

